-- phpMyAdmin SQL Dump
-- version 4.0.6deb1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 01-10-2015 a las 10:22:51
-- Versión del servidor: 5.5.37-0ubuntu0.13.10.1
-- Versión de PHP: 5.5.3-1ubuntu2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `kengo_facturacion`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `kng_ciudades`
--

CREATE TABLE IF NOT EXISTS `kng_ciudades` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `provincia` mediumint(9) NOT NULL DEFAULT '0',
  `nombre` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activo` enum('0','1') COLLATE utf8_unicode_ci DEFAULT '1',
  `borrado` enum('0','1') COLLATE utf8_unicode_ci DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `provincia` (`provincia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `kng_clientes`
--

CREATE TABLE IF NOT EXISTS `kng_clientes` (
  `id` mediumint(11) NOT NULL AUTO_INCREMENT,
  `cif` varchar(9) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nombre` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `web` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `direccion` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `cp` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ciudad` mediumint(11) NOT NULL DEFAULT '0',
  `provincia` mediumint(11) NOT NULL DEFAULT '0',
  `pais` mediumint(11) NOT NULL DEFAULT '0',
  `telefono` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fax` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `activo` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `borrado` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `kng_conceptos`
--

CREATE TABLE IF NOT EXISTS `kng_conceptos` (
  `id` mediumint(11) NOT NULL AUTO_INCREMENT,
  `presupuesto` mediumint(11) NOT NULL DEFAULT '0',
  `proforma` mediumint(11) NOT NULL,
  `factura` mediumint(11) NOT NULL DEFAULT '0',
  `num` mediumint(11) NOT NULL DEFAULT '0',
  `concepto` text COLLATE utf8_unicode_ci NOT NULL,
  `precio` double(10,2) NOT NULL DEFAULT '0.00',
  `cantidad` int(10) NOT NULL DEFAULT '0',
  `activo` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `borrado` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `kng_contactos`
--

CREATE TABLE IF NOT EXISTS `kng_contactos` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `empresa` mediumint(9) DEFAULT NULL,
  `perfil` mediumint(9) DEFAULT NULL,
  `nombre` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `apellido1` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `apellido2` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono` mediumint(9) DEFAULT NULL,
  `extension` mediumint(9) DEFAULT NULL,
  `movil` mediumint(9) DEFAULT NULL,
  `observaciones` text COLLATE utf8_unicode_ci,
  `activo` enum('0','1') COLLATE utf8_unicode_ci DEFAULT '1',
  `borrado` enum('0','1') COLLATE utf8_unicode_ci DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_contactos_perfiles1` (`perfil`),
  KEY `empresa` (`empresa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `kng_cuentas`
--

CREATE TABLE IF NOT EXISTS `kng_cuentas` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `cuenta` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `banco` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activo` enum('0','1') COLLATE utf8_unicode_ci DEFAULT '1',
  `borrado` enum('0','1') COLLATE utf8_unicode_ci DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `kng_eventos`
--

CREATE TABLE IF NOT EXISTS `kng_eventos` (
  `id` mediumint(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) NOT NULL,
  `fecha` date NOT NULL,
  `precio` double(10,2) NOT NULL,
  `notas` text NOT NULL,
  `activo` enum('0','1') NOT NULL DEFAULT '1',
  `borrado` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `kng_facturas`
--

CREATE TABLE IF NOT EXISTS `kng_facturas` (
  `id` mediumint(11) NOT NULL AUTO_INCREMENT,
  `presupuesto` mediumint(11) NOT NULL DEFAULT '0',
  `numero` int(10) NOT NULL DEFAULT '0',
  `tipo` mediumint(11) NOT NULL DEFAULT '1',
  `cliente` mediumint(11) NOT NULL DEFAULT '0' COMMENT 'lo pilla de la tabla de clientes',
  `fecha` date NOT NULL DEFAULT '0000-00-00',
  `cuenta` int(11) NOT NULL DEFAULT '1' COMMENT 'lo pilla de la tabla de cuentas',
  `titulo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `notas` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `factura_numero` (`numero`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `kng_hojasruta`
--

CREATE TABLE IF NOT EXISTS `kng_hojasruta` (
  `id` mediumint(11) unsigned NOT NULL AUTO_INCREMENT,
  `artista` varchar(255) NOT NULL,
  `fecha` date NOT NULL,
  `ciudad` varchar(255) NOT NULL,
  `produccion` varchar(255) NOT NULL,
  `responsable` varchar(255) NOT NULL,
  `email_responsable` varchar(255) NOT NULL,
  `tlf_resp` varchar(255) NOT NULL,
  `resp_produccion` varchar(255) NOT NULL,
  `tlf_resp_prod` varchar(255) NOT NULL,
  `resp_sonido` varchar(255) NOT NULL,
  `tlf_resp_soni` varchar(255) NOT NULL,
  `lugar` varchar(255) NOT NULL,
  `direccion` varchar(255) NOT NULL,
  `soundcheck` text NOT NULL,
  `actuaciones` text NOT NULL,
  `observaciones` text NOT NULL,
  `activo` enum('0','1') NOT NULL DEFAULT '1',
  `borrado` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `kng_pagos`
--

CREATE TABLE IF NOT EXISTS `kng_pagos` (
  `id` mediumint(11) NOT NULL AUTO_INCREMENT,
  `factura` mediumint(11) NOT NULL DEFAULT '0',
  `fecha` date NOT NULL DEFAULT '0000-00-00',
  `cantidad` double NOT NULL DEFAULT '0',
  `borrado` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `kng_paises`
--

CREATE TABLE IF NOT EXISTS `kng_paises` (
  `id` mediumint(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `activo` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `borrado` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `kng_paises`
--

INSERT INTO `kng_paises` (`id`, `nombre`, `activo`, `borrado`) VALUES
(1, 'España', '1', '0');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `kng_presupuestos`
--

CREATE TABLE IF NOT EXISTS `kng_presupuestos` (
  `id` mediumint(11) NOT NULL AUTO_INCREMENT,
  `numero` int(10) NOT NULL DEFAULT '0',
  `cliente` mediumint(11) NOT NULL DEFAULT '0' COMMENT 'lo pilla de la tabla de clientes',
  `fecha` date NOT NULL DEFAULT '0000-00-00',
  `titulo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `notas` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `kng_proformas`
--

CREATE TABLE IF NOT EXISTS `kng_proformas` (
  `id` mediumint(11) NOT NULL AUTO_INCREMENT,
  `presupuesto` mediumint(11) NOT NULL DEFAULT '0',
  `numero` int(10) NOT NULL DEFAULT '0',
  `tipo` mediumint(11) NOT NULL DEFAULT '1',
  `cliente` mediumint(11) NOT NULL DEFAULT '0' COMMENT 'lo pilla de la tabla de clientes',
  `fecha` date NOT NULL DEFAULT '0000-00-00',
  `cuenta` int(11) NOT NULL DEFAULT '1' COMMENT 'lo pilla de la tabla de cuentas',
  `titulo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `notas` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `factura_numero` (`numero`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `kng_provincias`
--

CREATE TABLE IF NOT EXISTS `kng_provincias` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activo` enum('0','1') COLLATE utf8_unicode_ci DEFAULT '1',
  `borrado` enum('0','1') COLLATE utf8_unicode_ci DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `kng_tiposfactura`
--

CREATE TABLE IF NOT EXISTS `kng_tiposfactura` (
  `id` mediumint(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `activo` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `borrado` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zkng_admins`
--

CREATE TABLE IF NOT EXISTS `zkng_admins` (
  `id` mediumint(11) NOT NULL AUTO_INCREMENT,
  `nick` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `pass` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `mail` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `rol` mediumint(11) NOT NULL DEFAULT '0',
  `activo` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `zkng_admins`
--

INSERT INTO `zkng_admins` (`id`, `nick`, `pass`, `mail`, `rol`, `activo`) VALUES
(1, 'admin', '21232F297A57A5A743894A0E4A801FC3', 'admin@yoursite.com', 1, '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zkng_idiomas`
--

CREATE TABLE IF NOT EXISTS `zkng_idiomas` (
  `id` mediumint(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `descripcion` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `posicion` int(10) NOT NULL DEFAULT '0',
  `activo` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Volcado de datos para la tabla `zkng_idiomas`
--

INSERT INTO `zkng_idiomas` (`id`, `nombre`, `descripcion`, `posicion`, `activo`) VALUES
(1, 'es', 'espaÃ±ol', 1, '1'),
(2, 'en', 'english', 2, '0'),
(3, 'eu', 'euskara', 3, '0'),
(4, 'fr', 'franÃ§ais', 4, '0'),
(5, 'it', 'italiano', 5, '0'),
(6, 'ca', 'catalÃ ', 6, '0'),
(7, 'pt', 'portugues', 7, '0');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zkng_menu`
--

CREATE TABLE IF NOT EXISTS `zkng_menu` (
  `id` mediumint(11) NOT NULL AUTO_INCREMENT,
  `dios` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `txt` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `es` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `padre` mediumint(11) NOT NULL DEFAULT '0',
  `pos` int(10) NOT NULL DEFAULT '99',
  `tipo` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `admin` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `estatico` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `galeria` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `color` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `en` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `eu` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fr` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `it` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ca` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `pt` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zkng_menu_admin`
--

CREATE TABLE IF NOT EXISTS `zkng_menu_admin` (
  `a_id` mediumint(11) NOT NULL AUTO_INCREMENT,
  `a_nombre` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `a_padre` mediumint(11) NOT NULL DEFAULT '0',
  `txt` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `a_pos` int(10) NOT NULL DEFAULT '0',
  `a_nivel` int(10) NOT NULL DEFAULT '0',
  `activo` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`a_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `zkng_menu_admin`
--

INSERT INTO `zkng_menu_admin` (`a_id`, `a_nombre`, `a_padre`, `txt`, `a_pos`, `a_nivel`, `activo`) VALUES
(1, 'administradores', 0, 'administradores', 1, 1, '1'),
(2, 'roles', 0, 'roles', 2, 1, '1'),
(3, 'idiomas', 0, 'idiomas', 3, 1, '1'),
(4, 'BBDD', 0, 'mysql', 4, 1, '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zkng_menu_fac`
--

CREATE TABLE IF NOT EXISTS `zkng_menu_fac` (
  `id` mediumint(11) NOT NULL AUTO_INCREMENT,
  `dios` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `txt` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `es` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `padre` mediumint(11) NOT NULL DEFAULT '0',
  `pos` int(10) NOT NULL DEFAULT '99',
  `tipo` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `admin` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `estatico` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `en` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `eu` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fr` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `it` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ca` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `pt` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Volcado de datos para la tabla `zkng_menu_fac`
--

INSERT INTO `zkng_menu_fac` (`id`, `dios`, `txt`, `es`, `padre`, `pos`, `tipo`, `admin`, `estatico`, `en`, `eu`, `fr`, `it`, `ca`, `pt`) VALUES
(1, '0', 'facturas', 'facturas', 0, 30, '0', '1', '0', '', '', '', '', '', ''),
(2, '0', 'clientes', 'clientes', 0, 60, '0', '1', '0', '', '', '', '', '', ''),
(3, '0', 'ciudades', 'ciudades', 0, 70, '0', '1', '0', '', '', '', '', '', ''),
(4, '0', 'provincias', 'provincias', 0, 80, '0', '1', '0', '', '', '', '', '', ''),
(5, '0', 'cuentas', 'cuentas', 0, 90, '0', '1', '0', '', '', '', '', '', ''),
(6, '0', 'presupuestos', 'presupuestos', 0, 10, '0', '1', '0', '', '', '', '', '', ''),
(7, '0', 'eventos', 'eventos', 0, 40, '1', '1', '0', '', '', '', '', '', ''),
(8, '0', 'hojaruta', 'hojas de ruta', 0, 50, '0', '1', '0', '', '', '', '', '', ''),
(9, '0', 'tiposfactura', 'Tipos factura', 0, 0, '1', '1', '0', '', '', '', '', '', ''),
(10, '0', 'proformas', 'proformas', 0, 20, '1', '1', '0', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zkng_roles`
--

CREATE TABLE IF NOT EXISTS `zkng_roles` (
  `id` mediumint(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Volcado de datos para la tabla `zkng_roles`
--

INSERT INTO `zkng_roles` (`id`, `nombre`) VALUES
(1, 'Administrador');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `zkng_rolmenu`
--

CREATE TABLE IF NOT EXISTS `zkng_rolmenu` (
  `rolmenu_id` mediumint(11) NOT NULL AUTO_INCREMENT,
  `rolmenu_rol` mediumint(11) NOT NULL DEFAULT '0',
  `rolmenu_menu` mediumint(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`rolmenu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
